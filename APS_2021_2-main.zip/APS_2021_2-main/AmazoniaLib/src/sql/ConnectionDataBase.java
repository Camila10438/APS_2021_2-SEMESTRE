package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import assets.NameConfig;

public class ConnectionDataBase {

	/**
	 * faz uma tentativa de iniciar a conex�o com o banco de dados
	 * @return objeto conex�o j� conectado
	 */
    public static Connection getConnection() {
        try {
            Class.forName(NameConfig.DRIVER_CLASS);
            return DriverManager.getConnection(NameConfig.URL_POSTGRES, NameConfig.USER, NameConfig.PASS);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
}