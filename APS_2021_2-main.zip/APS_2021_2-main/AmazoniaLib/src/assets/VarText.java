package assets;

public class VarText {
	
	// ----------------------------------- Config -----------------------------------
	private final static String closer = "()"; // Caracteres padrão de encapsulamento
	//-------------------------------------------------------------------------------
	
	/**
	 * Aninha as strings recebidas entre virgulas e fecha o conjunto com {@value #closer}
	 * @param strs - Array de Strings (Ex: {"a", "b", "c"})
	 * @return strings - Text formatado (Ex: "(a,b,c)")
	 */
	public static String listText(String[] strs) {
		String res = closer.substring(0, 1);
		for (String str : strs) {
			try {
				Integer.parseInt(str);
				res += "?" + ((closer.length()>2) ? ", " : ",");
			} catch (java.lang.NumberFormatException e) {
				res +=   "?" + ((closer.length()>2) ? ", " : ",");
			}
		}
		res = res.substring(0, res.length() - ((closer.length()>2) ? 2 : 1)) + closer.substring(1, 2);
		return res;
	}
	
	/**
	 * percorre uma lista procurando um item
	 * @param list - a lista a ser percorrida
	 * @param item - o item a ser verificado na lista
	 * @return Boolean - True (lista contem o item), False (lista não contem o item)
	 */
	public static boolean contais(Object[] list, Object item) {
		for (Object i : list) {
			if (i.equals(item)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Converte uma array de ints para array de strings
	 * @param inp - array de ints
	 * @return String[] - array convertida
	 */
	public static String[] convert(int[] inp) {
		String[] res = new String[inp.length]; 
		for (int i = 0; i < inp.length; i++) {
			res[i] = String.valueOf(inp[i]);
		}
		return res;
	}

}
