/*
 * Made By
 * |--          Nome               --|--   RA   --|
 * | Amanda Alves dos Santos Santana |  #F2582I-2 |
 * | Camila Rodrigues Moura          |  #N539747  |
 * | Camille de Almeida O. Barbosa   |  #N684GC4  |
 * | Leila Viana Contel              |  #N593091  |
 * | Rafael Gabriel Alves Sabadini   |  #N5750B5  |
 * \---------------------------------+------------/
 */

package assets;

/**
 * Configura��es de nomes para facilitar a organiza��o e modifica��o dos textos no projeto,
 * al�m da conex�o com BD.
 */
public final class NameConfig {
	
	// -------------------------------- Config --------------------------------
	public static final String URL_POSTGRES = "jdbc:postgresql://localhost:5432/Biblioteca"; // url do banco de dados
	public static final String DRIVER_CLASS = "org.postgresql.Driver";                       // classe do driver
	public static final String USER         = "postgres";                                    // usu�rio pra acesso ao BD
	public static final String PASS         = "1911";                                        // senha de acesso do BD
	// ------------------------------------------------------------------------
	
	
	// Geral
	public final static String return_button = "Voltar";
	public final static String add_button    = "Adicionar";
	public final static String edit_button   = "Editar";
	public final static String del_button    = "Excluir";
	
	
	// Menu
	public final static String Menu_base_tag    = "View";
	public final static String Authors_tag      = "Authors";
	public final static String Books_tag        = "Books";
	public final static String Publishers_tag   = "Publishers";
	public final static String Booksauthors_tag = "Books Authors";
	public final static String Menu_exit_tag    = "Sair";
	public final static String Exit_tag         = "Fechar";
	
	
	// Authors
	public final static String Authors_tab   = "Authors";
	public final static String Authors_add   = "Adicionar";
	public final static String Authors_id    = "ID";
	public final static String Authors_name  = "Name";
	public final static String Authors_fname = "First Name";
	
	
	// Books
	public final static String Books_tab   = "Books";
	public final static String Books_add   = "Adicionar";
	public final static String Books_title = "Title";
	public final static String Books_isbn  = "ISBN";
	public final static String Books_id    = "Publisher ID";
	public final static String Books_price = "Price";
	public final static String Books_del   = "Excluir";
	
	
	// Publishers
	public final static String Publishers_tab  = "Publishers";
	public final static String Publishers_id   = "ID";
	public final static String Publishers_name = "Nome";
	public final static String Publishers_url  = "URL";
	
	
	// Books Authors
	public final static String Booksauthors_id   = "Author id";
	public final static String Booksauthors_seq = "Seq n�";
	public final static String Booksauthors_isbn  = "ISBN";
	
}
