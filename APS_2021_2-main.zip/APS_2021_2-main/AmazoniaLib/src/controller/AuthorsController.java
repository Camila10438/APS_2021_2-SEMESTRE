package controller;

import dao.AuthorDao;
import model.AuthorsModel;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

public class AuthorsController {

	/**
	 * Salva um novo autor de livros no BD
	 * @param id id do autor
	 * @param nome nome do autor
	 * @param fname primeiro nome do autor
	 * @throws SQLException - caso haja erro de conex�o com o BD
	 * @throws ParseException - caso os dados sejam entregues de forma incorreta
	 */
    public void salvar(String id, String nome, String fname) throws SQLException, ParseException {
        String[] campos = new String[3];
        campos[0] = id;
        campos[1] = nome;
        campos[2] = fname;
        new AuthorDao().save("authors", campos);
    }

    /**
     * Lista todos os autores no BD.
     * @return lista de autores
     */
    public List<AuthorsModel> listAll() {
        try {
            return new AuthorDao().listarTodos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Atualiza algum autor no BD.
     * @param author_id id antigo do autor.
     * @param name novo nome do autor
     * @param fname novo primeiro nome do autor
     * @throws SQLException caso haja erro de conex�o com o BD
     */
    public void update(Object author_id, Object name, Object fname) throws SQLException {
    	new AuthorDao().update(author_id, name, fname);
    }
    
    /**
     * Apaga um registro no BD
     * @param parameter parametros do registro a ser adicionado
     * @throws SQLException caso haja erro de conex�o com o BD
     */
    public void delete(Object... parameter) throws SQLException {
    	new AuthorDao().delete(parameter);
    }
}
