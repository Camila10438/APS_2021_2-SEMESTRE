package controller;

import dao.AuthorDao;
import dao.BooksAuthorsDao;
import model.AuthorsModel;
import model.BooksAuthorsModel;
import model.BooksModel;
import model.PublishersModel;
import sql.ConnectionDataBase;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

@SuppressWarnings("unused")
public class BooksAuthorsController {

	/**
	 * Salva uma nova rela��o autor-livro no BD
	 * @param isbn c�digo de registro de livro
	 * @param author_id id do autor
	 * @param seq_no primeiro numero de sequ�ncia
	 * @throws SQLException - caso haja erro de conex�o com o BD
	 * @throws ParseException - caso os dados sejam entregues de forma incorreta
	 */
	public void salvar(String isbn, String author_id, String seq_no) throws SQLException, ParseException {
        String[] campos = new String[3];
        campos[0] = isbn;
        campos[1] = author_id;
        campos[2] = seq_no;
        new BooksAuthorsDao().save("booksauthors", campos);
    }

	/**
     * Lista todas as rela��es entre autores-livros.
     * @return lista de rela��es
     */
    public List<BooksAuthorsModel> listAll(){
        try {
            return new BooksAuthorsDao().listarTodos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Apaga uma rela��o autores-livros
     * @param parameter seq_no a serem deletados
     * @throws SQLException - caso haja erro de conex�o com o BD
     */
    public void delete(Object... parameter) throws SQLException {
    	new BooksAuthorsDao().delete(parameter);
    }
    
    /**
     * Atualiza uma rela��o autores-livros
     * @param isbn c�digo de livro
     * @param idx c�digo seq_no
     * @throws SQLException - caso haja erro de conex�o com o BD
     */
    public void update(Object isbn, Object idx) throws SQLException {
    	new BooksAuthorsDao().update(isbn, idx);
    }
    
    /**
     * retorna uma coluna inteira do BD
     * @param index numero da coluna
     * @return lista com os dados da coluna
     */
    public String[] getcolumn(int index) {
    	List<BooksAuthorsModel> bam = listAll();
    	String[] res = new String[bam.size()];
    	for (int i = 0; i < bam.size(); i++) {
    		if (index==1) {
    			res[i] = bam.get(i).getIsbn().toString();
    		} else if (index==2) {
    			res[i] = bam.get(i).getAuthor_id().toString();
    		} else if (index==3) {
    			res[i] = bam.get(i).getSeq_no().toString();
    		}
    		
    		if(res[i].indexOf(' ')!=-1) {
    			res[i] = res[i].substring(0, res[i].indexOf(' '));
    		}
    	}
    	return res;
    }
    
    /**
     * retorna o isbn de todos os livros no BD
     * @return lista de isbn de livros
     */
    public String[] getBooks(){
    	BooksController bookscontroller = new BooksController();
    	List<BooksModel> books = bookscontroller.listAll();
    	
    	String[] res = new String[books.size()];
    	int i = -1;
    	for (BooksModel book : books) {
    		i++;
    		res[i] = book.getIsbn();
    		if(res[i].indexOf(' ')!=-1) {
    			res[i] = res[i].substring(0, res[i].indexOf(' '));
    		}
    	}
    	
    	return res;
    }
    
    /**
     * Retorna uma lista com o nome todos os nomes de autores
     * @return lista com nomes
     */
    public String[] getAuthors(){
    	AuthorsController authorscontroller = new AuthorsController();
    	List<AuthorsModel> authors = authorscontroller.listAll();
    	
    	String[] res = new String[authors.size()];
    	int i = -1;
    	for (AuthorsModel author : authors) {
    		i++;
    		res[i] = String.valueOf(author.getAuthor_Id());
    	}
    	
    	return res;
    }
}
