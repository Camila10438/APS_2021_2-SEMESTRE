package controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import dao.*;
import model.BooksModel;

public class BooksController {

	/**
	 * Salva um novo registro de um livro
	 * @param title t�tulo do livro
	 * @param isbn c�digo de identifica��o do livro
	 * @param publisher_id id da editora
	 * @param price pre�o do livro
	 * @throws SQLException - caso haja erro de conex�o com o BD
	 * @throws ParseException - caso os dados sejam entregues de forma incorreta
	 */
    public void salvar(String title, String isbn, String publisher_id, String price)
            throws SQLException, ParseException
    {
        String[] campos = new String[4];
        campos[0] = title;
        campos[1] = isbn;
        campos[2] = publisher_id;
        campos[3] = price;
        new BookDao().save("books", campos);
    }

    /**
     * Retorna uma lista de livro
     * @return Lista de livros
     */
    public List<BooksModel> listAll(){
        try {
            return new BookDao().listarTodos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Atualiza um livro do Registro
     * @param isbn antigo c�digo do livro
     * @param title novo t�tulo do livro
     * @param id novo id da editora do livro
     * @param price novo pre�o
     * @throws SQLException - caso haja erro de conex�o com o banco de dados
     */
    public void update(Object isbn, Object title, Object id, Object price) throws SQLException {
    	new BookDao().update(title, isbn, id, price);
    }
    
    /**
     * Apaga um livro do registro
     * @param parameter lista de parametros a serem apagados
     * @throws SQLException  - caso haja erro de conex�o com o banco de dados
     */
    public void delete(Object... parameter) throws SQLException {
    	new BookDao().delete(parameter);
    }
}
