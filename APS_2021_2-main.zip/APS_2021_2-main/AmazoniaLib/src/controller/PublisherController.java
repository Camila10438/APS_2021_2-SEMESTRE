package controller;

import dao.PublisherDao;
import model.PublishersModel;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

public class PublisherController {

	/**
	 * salva uma nova editora
	 * @param id id da editora
	 * @param nome nome da editora
	 * @param url url da editora
	 * @throws SQLException - caso haja erro de conex�o com o banco de dados
	 * @throws ParseException - caso os dados sejam entregues de forma incorreta
	 */
    public void salvar(String id, String nome, String url)
            throws SQLException, ParseException
    {
        String[] campos = new String[3];
        campos[0] = id;
        campos[1] = nome;
        campos[2] = url;
        new PublisherDao().save("publishers", campos);
    }

    /**
     * retorna a lista de editoras
     * @return lista de editoras
     */
    public List<PublishersModel> listAll(){
        try {
            return new PublisherDao().listarTodos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * atualiza os dados de uma editora
     * @param publishers_id antigo id da editora
     * @param name novo nome da editora
     * @param url novo url da editora
     * @throws SQLException - caso haja erro de conex�o com o banco de dados
     */
    public void update(Object publishers_id, Object name, Object url) throws SQLException {
    	new PublisherDao().update(publishers_id, name, url);
    }
    
    /**
     * Apaga uma editora do registro
     * @param parameter lista de parametros a serem apagados
     * @throws SQLException - caso haja erro de conex�o com o banco de dados
     */
    public void delete(Object... parameter) throws SQLException {
    	new PublisherDao().delete(parameter);
    }
}
