package model;

public class BooksModel {
    
    private String title;
    private String isbn;
    private Integer publisher_Id;
    private Double price;
    
    public BooksModel(){
    }
    
    public BooksModel(String aTitle, String aISBN, Integer aPublisher_Id, Double aPrice){
        title = aTitle;
        isbn = aISBN;
        publisher_Id = aPublisher_Id;
        price = aPrice;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Integer getPublisher_Id() {
        return publisher_Id;
    }

    public void setPublisher_Id(Integer publisher_Id) {
        this.publisher_Id = publisher_Id;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }  
}
