package model;

public class PublishersModel {
    
    private Integer publisher_Id;
    private String name;
    private String url;
    
    public PublishersModel(){
    }
    
    public PublishersModel(Integer aPublisher_Id, String aName, String aURL){
        publisher_Id = aPublisher_Id;
        name = aName;
        url = aURL;
    }

    public Integer getPublisher_Id() {
        return publisher_Id;
    }

    public void setPublisher_Id(Integer publisher_Id) {
        this.publisher_Id = publisher_Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }  

    public int getpublisher_id() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
