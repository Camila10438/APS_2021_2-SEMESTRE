package model;

public class AuthorsModel {
    
    private Integer author_Id;
    private String name;
    private String Fname;
    
    public AuthorsModel(){
    }
    
    public AuthorsModel(Integer aAuthor_Id, String aName, String aFname){
        author_Id = aAuthor_Id;
        name = aName;
        Fname = aFname;
    }

    public Integer getAuthor_Id() {
        return author_Id;
    }

    public void setAuthor_Id(Integer author_Id) {
        this.author_Id = author_Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }   
}
