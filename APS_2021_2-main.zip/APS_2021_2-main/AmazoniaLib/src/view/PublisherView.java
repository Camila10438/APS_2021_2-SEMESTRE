package view;

import controller.PublisherController;
import model.PublishersModel;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import assets.NameConfig;

@SuppressWarnings("serial")
public class PublisherView extends javax.swing.JFrame {

    PublishersModel publishers;

    public PublisherView() {
        initComponents();
    }

    private void initComponents() {

        lblId = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblURL = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtURL = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnVoltar = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablePublishers = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 153, 153));
        setForeground(new java.awt.Color(0, 0, 0));

        lblId.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblId.setText(NameConfig.Publishers_id + ":");

        lblName.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblName.setText(NameConfig.Publishers_name + ":");

        lblURL.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblURL.setText(NameConfig.Publishers_url + ":");

        txtId.setBackground(new java.awt.Color(0, 204, 204));
        txtId.setForeground(new java.awt.Color(255, 255, 255));

        txtName.setBackground(new java.awt.Color(0, 204, 204));

        txtURL.setBackground(new java.awt.Color(0, 204, 204));

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 3, 48)); // NOI18N
        jLabel1.setText(NameConfig.Publishers_tab);

        btnVoltar.setBackground(new java.awt.Color(0, 153, 153));
        btnVoltar.setText(NameConfig.return_button);
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnSalvar.setBackground(new java.awt.Color(0, 153, 153));
        btnSalvar.setText(NameConfig.add_button);
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        updateview();
        jScrollPane1.setViewportView(tablePublishers);

        btnEditar.setBackground(new java.awt.Color(0, 153, 153));
        btnEditar.setText(NameConfig.edit_button);
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setBackground(new java.awt.Color(0, 153, 153));
        btnExcluir.setText(NameConfig.del_button);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblURL)
                            .addComponent(lblName)
                            .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtId)
                            .addComponent(txtName, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtURL)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(84, 84, 84)
                                .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(25, 25, 25))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtName, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                    .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtURL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblURL, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addGap(18, 18, 18)
                .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispose();
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "salvar" presionado
     */
    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
    	try {
        	if(txtId.getText().equals("") || txtName.getText().equals("") || txtURL.getText().equals("")) {
        		throw new Exception("Por favor preencha todos os campos!");
        	} else {
	        	try {
	        		int tmp_int_insb = Integer.parseInt(txtId.getText());
	        		if(tmp_int_insb < 0) {
	        			throw new Exception("Id inv�lido (o Id não pode ser negativo!)");
	        		}
	        	} catch (java.lang.NumberFormatException e) {
	        		throw new Exception("Id inv�lido (use um número inteiro!)");
	        	}
        	}
        	
        	PublisherController pc = new PublisherController();

    	    pc.salvar(txtId.getText(), txtName.getText(), txtURL.getText());

	        JOptionPane.showMessageDialog(null, txtName.getText() + " Cadastrado com sucesso!");
	        updateview();
	        txtId.setText("");
	        txtName.setText("");
                txtURL.setText("");
		} catch (org.postgresql.util.PSQLException e) {
    		if (e.getMessage().contains("duplicate")) {
    			JOptionPane.showMessageDialog(null, "J� Existe um editora com esse ID, por favor digite outro!");
    		}
		} catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    	} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "editar" presionado
     */
    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {
    	try {
    		int idx = Integer.parseInt(tablePublishers.getModel().getValueAt(tablePublishers.getSelectedRow(), 0).toString());
    		String name = tablePublishers.getModel().getValueAt(tablePublishers.getSelectedRow(), 1).toString();
    		String url = tablePublishers.getModel().getValueAt(tablePublishers.getSelectedRow(), 2).toString();
    		name = name.replaceAll(" +", " ");
    		url = url.replaceAll(" +", " ");
    		PublisherController pc = new PublisherController();
    		pc.update(idx, name, url);
    		JOptionPane.showMessageDialog(null, name + " modificado com sucesso!");
    		updateview();
    	} catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    	} catch (ArrayIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Selecione uma linha na tabela para apaga-la!");
    	}
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "deletar" presionado
     */
    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
    	int idx2 = 0;
    	try {
    		int idx = Integer.parseInt(tablePublishers.getModel().getValueAt(tablePublishers.getSelectedRow(), 0).toString());
    		idx2 = idx;
    		PublisherController pc = new PublisherController();
	    	pc.delete(idx);
	    	updateview();
    	} catch (SQLException e) {
    		if (e.getMessage().contains("foreign key")) {
    			JOptionPane.showMessageDialog(null, "o item de ID " + String.valueOf(idx2) + " n�o pode ser deletado pois � referenciado em outra tabela!");
    		} else {
    			e.printStackTrace();
    		}
    	} catch (ArrayIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Selecione uma linha na tabela para apaga-la!");
    	}
    }

    /**
     * atualiza a tabela de editoras
     */
    private void updateview() {
    	String colunas[] = {NameConfig.Publishers_id, NameConfig.Publishers_name, NameConfig.Publishers_url};

        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
        PublisherController pc = new PublisherController();
        List<PublishersModel> lista = pc.listAll();
        for(PublishersModel p: lista){
            modelo.addRow(new String[]{String.valueOf(p.getPublisher_Id()), p.getName(), p.getUrl()});
        }

        tablePublishers.setModel(modelo);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PublisherView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PublisherView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PublisherView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PublisherView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PublisherView().setVisible(true);
            }
        });
    }

    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblURL;
    private javax.swing.JTable tablePublishers;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtURL;
    
}
