package view;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import assets.NameConfig;
import controller.BooksController;
import model.*;

@SuppressWarnings("serial")
public class BookView extends javax.swing.JFrame {

    BooksModel books;

    public BookView() {
        initComponents();
    }

    private void initComponents() {

        btnVoltar = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        lblISBN = new javax.swing.JLabel();
        lblPublisherId = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        txtTitle = new javax.swing.JTextField();
        txtISBN = new javax.swing.JTextField();
        txtPublisherId = new javax.swing.JTextField();
        Books = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableBooks = new javax.swing.JTable();
        btnExcluir = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 204));

        btnVoltar.setBackground(new java.awt.Color(0, 153, 153));
        btnVoltar.setText(NameConfig.return_button);
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnSalvar.setBackground(new java.awt.Color(0, 153, 153));
        btnSalvar.setText(NameConfig.add_button);
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        lblTitle.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblTitle.setText(NameConfig.Books_title + ":");

        lblISBN.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblISBN.setText(NameConfig.Books_isbn + ":");

        lblPublisherId.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblPublisherId.setText(NameConfig.Books_id + ":");

        lblPrice.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblPrice.setText(NameConfig.Books_price + ":");

        txtTitle.setBackground(new java.awt.Color(0, 204, 204));
        txtTitle.setForeground(new java.awt.Color(255, 255, 255));

        txtISBN.setBackground(new java.awt.Color(0, 204, 204));

        txtPublisherId.setBackground(new java.awt.Color(0, 204, 204));

        Books.setFont(new java.awt.Font("Lucida Sans Unicode", 3, 48));
        Books.setText(NameConfig.Books_tab);

        txtPrice.setBackground(new java.awt.Color(0, 204, 204));

        updateview();
        jScrollPane2.setViewportView(tableBooks);

        btnExcluir.setBackground(new java.awt.Color(0, 153, 153));
        btnExcluir.setText(NameConfig.del_button);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnEditar.setBackground(new java.awt.Color(0, 153, 153));
        btnEditar.setText(NameConfig.edit_button);
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(180, 180, 180)
                .addComponent(Books, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(lblPublisherId)
                                .addComponent(lblISBN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblPrice))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtISBN, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                            .addComponent(txtPublisherId, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPrice, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTitle)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(72, 72, 72)
                                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(32, 32, 32))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(Books, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtISBN)
                    .addComponent(lblISBN, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtPublisherId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblPublisherId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "voltar" presionado
     */
    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispose();
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "salvar" presionado
     */
    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
    	try {
        	if(txtTitle.getText().equals("") || txtISBN.getText().equals("") || txtPublisherId.getText().equals("") || txtPrice.getText().equals("")) {
        		throw new Exception("Por favor preencha todos os campos!");
        	} else {
	        	try {
	        		int tmp_int_insb = Integer.parseInt(txtISBN.getText());
	        		if(tmp_int_insb < 0) {
	        			throw new Exception("ISBN inv�lido (o ISBN n�o pode ser negativo!)");
	        		}
	        	} catch (java.lang.NumberFormatException e) {
	        		throw new Exception("ISBN inv�lido (use um n�mero inteiro!)");
	        	}
        	}
		
        	BooksController pc = new BooksController();

    	    pc.salvar(txtTitle.getText(), txtISBN.getText(), txtPublisherId.getText(), txtPrice.getText());
                
	        JOptionPane.showMessageDialog(null, txtTitle.getText() + " Cadastrado com sucesso!");
	        updateview();
	        txtTitle.setText("");
	        txtISBN.setText("");
            txtPublisherId.setText("");
            txtPrice.setText("");
		} catch (org.postgresql.util.PSQLException e) {
    		if (e.getMessage().contains("duplicate")) {
    			JOptionPane.showMessageDialog(null, "J� Existe um livro com essa isbn, por favor digite outra!");
    		}
		} catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    	} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
    		e.printStackTrace();
		}
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "excluir" presionado
     */
    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
    	String idx2 = "";
    	try {
    		String idx = tableBooks.getModel().getValueAt(tableBooks.getSelectedRow(), 0).toString();
    		idx2 = idx;
	    	BooksController pc = new BooksController();
	    	pc.delete(idx);
	    	updateview();
    	} catch (SQLException e) {
    		if (e.getMessage().contains("foreign key")) {
    			JOptionPane.showMessageDialog(null, "o livro " + idx2 + " n�o pode ser deletado pois � referenciado em outra tabela!");
    		} else {
    			 JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    		}
    	} catch (ArrayIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Selecione uma linha na tabela para apaga-la!");
    	}
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "editar" presionado
     */
    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {
    	try {
    		String idx_x = tableBooks.getModel().getValueAt(tableBooks.getSelectedRow(), 1).toString();
    		String idx = idx_x.substring(0, idx_x.indexOf(' '));
    		String title = tableBooks.getModel().getValueAt(tableBooks.getSelectedRow(), 0).toString();
    		int id = Integer.parseInt(tableBooks.getModel().getValueAt(tableBooks.getSelectedRow(), 2).toString());
    		double price = Double.parseDouble(tableBooks.getModel().getValueAt(tableBooks.getSelectedRow(), 3).toString());
    		title = title.replaceAll(" +", " ");
    		BooksController pc = new BooksController();
    		pc.update(idx, title, id, price);
    		JOptionPane.showMessageDialog(null, title + " modificado com sucesso!");
    		updateview();
    	} catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    	} catch (ArrayIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Selecione uma linha na tabela para apaga-la!");
    	}
    }

    @SuppressWarnings("unused")
	private void tableBooksMouseClicked(java.awt.event.MouseEvent evt) {
        txtTitle.setText(tableBooks.getValueAt(tableBooks.getSelectedColumn(), 0).toString());
        txtISBN.setText(tableBooks.getValueAt(tableBooks.getSelectedColumn(), 1).toString());
        txtPublisherId.setText(tableBooks.getValueAt(tableBooks.getSelectedColumn(), 2).toString());
        txtPrice.setText(tableBooks.getValueAt(tableBooks.getSelectedColumn(), 3).toString());
    }

    /**
     * atualiza a tabela de livros
     */
    private void updateview(){
    	String colunas[] = {NameConfig.Books_title, NameConfig.Books_isbn, NameConfig.Books_id, NameConfig.Books_price};

        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
        BooksController pc = new BooksController();
        List<BooksModel> lista = pc.listAll();
        for(BooksModel p: lista){
            modelo.addRow(new String[]{p.getTitle(), p.getIsbn(), String.valueOf(p.getPublisher_Id()), String.valueOf(p.getPrice())});
        }

        tableBooks.setModel(modelo);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookView().setVisible(true);
            }
        });
    }

    private javax.swing.JLabel Books;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblISBN;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblPublisherId;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTable tableBooks;
    private javax.swing.JTextField txtISBN;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtPublisherId;
    private javax.swing.JTextField txtTitle;
}
