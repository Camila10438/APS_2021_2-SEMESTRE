package view;

import assets.NameConfig;

@SuppressWarnings("serial")
public class Menu extends javax.swing.JFrame {

    public Menu() {
        initComponents();
        setLocationRelativeTo(null);  
    }
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        InsertAuthor = new javax.swing.JMenuItem();
        InsertBook = new javax.swing.JMenuItem();
        InsertPublisher = new javax.swing.JMenuItem();
        ListBooksAuthors = new javax.swing.JMenuItem();
        Fechar1 = new javax.swing.JMenu();
        Fechar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jMenu1.setText(NameConfig.Menu_base_tag);
        jMenu1.setActionCommand("Insert");

        InsertAuthor.setBackground(new java.awt.Color(0, 153, 153));
        InsertAuthor.setText(NameConfig.Authors_tag);
        InsertAuthor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertAuthorActionPerformed(evt);
            }
        });
        jMenu1.add(InsertAuthor);

        InsertBook.setText(NameConfig.Books_tag);
        InsertBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertBookActionPerformed(evt);
            }
        });
        jMenu1.add(InsertBook);

        InsertPublisher.setText(NameConfig.Publishers_tag);
        InsertPublisher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertPublisherActionPerformed(evt);
            }
        });
        jMenu1.add(InsertPublisher);
        
        ListBooksAuthors.setText(NameConfig.Booksauthors_tag);
        ListBooksAuthors.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListBooksAuthorsActionPerformed(evt);
            }
        });
        jMenu1.add(ListBooksAuthors);

        jMenuBar1.add(jMenu1);

        Fechar1.setText(NameConfig.Menu_exit_tag);

        Fechar.setText(NameConfig.Exit_tag);
        Fechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FecharActionPerformed(evt);
            }
        });
        
        Fechar1.add(Fechar);
        jMenuBar1.add(Fechar1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
        );

        pack();
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "Author" presionado
     */
    private void InsertAuthorActionPerformed(java.awt.event.ActionEvent evt) {
        AuthorView AuthorView = new AuthorView();
        this.dispose();
        AuthorView.setVisible(true);
        AuthorView.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                Menu.this.setVisible(true);
            }
        
        });
    }                         

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "Books" presionado
     */
    private void InsertBookActionPerformed(java.awt.event.ActionEvent evt) {
        BookView BookView = new BookView();
          this.dispose();
          BookView.setVisible(true);
          BookView.addWindowListener(new java.awt.event.WindowAdapter() {
              @Override
              public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                  Menu.this.setVisible(true);
              }
          });
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "BooksAuthors" presionado
     */
    private void ListBooksAuthorsActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispose();
        BooksAuthorsView booksAuthorsView = new BooksAuthorsView();
        booksAuthorsView.setVisible(true);
        booksAuthorsView.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                Menu.this.setVisible(true);
            }
        });  
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "Publishers" presionado
     */
    private void InsertPublisherActionPerformed(java.awt.event.ActionEvent evt) {
    	this.dispose();
    	PublisherView publishers = new PublisherView();
    	publishers.setVisible(true);
    	publishers.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                Menu.this.setVisible(true);
            }
        });       
    }

    private void FecharActionPerformed(java.awt.event.ActionEvent evt) {
	System.exit(0);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }
    
    private javax.swing.JMenuItem Fechar;
    private javax.swing.JMenu Fechar1;
    private javax.swing.JMenuItem InsertAuthor;
    private javax.swing.JMenuItem InsertBook;
    private javax.swing.JMenuItem InsertPublisher;
    private javax.swing.JMenuItem ListBooksAuthors;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
}
