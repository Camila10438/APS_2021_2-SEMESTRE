package view;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.*;
import assets.NameConfig;
import controller.AuthorsController;

@SuppressWarnings("serial")
public class AuthorView extends javax.swing.JFrame {

	AuthorsModel authors;
	
    public AuthorView() {
        initComponents();
    }
    
    private void initComponents() {

        btnVoltar = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        lblId = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableAuthors = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 204));

        btnVoltar.setBackground(new java.awt.Color(0, 153, 153));
        btnVoltar.setText(NameConfig.return_button);
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnSalvar.setBackground(new java.awt.Color(0, 153, 153));
        btnSalvar.setText(NameConfig.add_button);
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        lblId.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblId.setText(NameConfig.Authors_id + ":");

        lblName.setFont(new java.awt.Font("Tahoma", 0, 16));
        lblName.setText(NameConfig.Authors_name + ":");

        txtId.setBackground(new java.awt.Color(0, 204, 204));
        txtId.setForeground(new java.awt.Color(255, 255, 255));

        txtName.setBackground(new java.awt.Color(0, 204, 204));

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 3, 48));
        jLabel1.setText(NameConfig.Authors_tab);
        
        updateview();
        jScrollPane1.setViewportView(tableAuthors);

        btnEditar.setBackground(new java.awt.Color(0, 153, 153));
        btnEditar.setText(NameConfig.edit_button);
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setBackground(new java.awt.Color(0, 153, 153));
        btnExcluir.setText(NameConfig.del_button);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(67, 67, 67)
                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblName)
                            .addComponent(lblId))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtId)
                            .addComponent(txtName, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(47, 47, 47))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(99, 99, 99))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtName, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
                    .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        pack();
        setLocationRelativeTo(null);
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "voltar" presionado
     */
    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {
     	this.dispose();
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "salvar" presionado
     */
    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
    	try {
        	if(txtId.getText().equals("") || txtName.getText().equals("")) {
        		throw new Exception("Por favor preencha todos os campos!");
        	} else {
	        	try {
	        		int tmp_int_insb = Integer.parseInt(txtId.getText());
	        		if(tmp_int_insb < 0) {
	        			throw new Exception("Id inv�lido (o Id n�o pode ser negativo!)");
	        		}
	        	} catch (java.lang.NumberFormatException e) {
	        		throw new Exception("Id inv�lido (use um n�mero inteiro!)");
	        	}
        	}

        	String fnm = txtName.getText();
        	fnm = fnm.substring(0, fnm.indexOf(' '));
        	
        	AuthorsController pc = new AuthorsController();
    	    pc.salvar(txtId.getText(), txtName.getText(), fnm);
    	    updateview();
                
	        JOptionPane.showMessageDialog(null, txtName.getText() + " Cadastrado com sucesso!");
	        txtId.setText("");
	        txtName.setText("");
    	} catch (java.lang.StringIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Por favor digite nome e sobrenome!");
    	} catch (org.postgresql.util.PSQLException e) {
    		if (e.getMessage().contains("duplicate")) {
    			JOptionPane.showMessageDialog(null, "J� Existe alguem com esse ID, por favor digite outro!");
    		}
		} catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    	} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
    		e.printStackTrace();
		}  
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "deletar" presionado
     */
    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
    	int idx2 = 0;
    	try {
    		int idx = Integer.parseInt(tableAuthors.getModel().getValueAt(tableAuthors.getSelectedRow(), 0).toString());
    		idx2 = idx;
	    	AuthorsController pc = new AuthorsController();
	    	pc.delete(idx);
	    	updateview();
    	} catch (SQLException e) {
    		if (e.getMessage().contains("foreign key")) {
    			JOptionPane.showMessageDialog(null, "o item de ID " + String.valueOf(idx2) + " n�o pode ser deletado pois � referenciado em outra tabela!");
    		} else {
    			JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    		}
    	} catch (ArrayIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Selecione uma linha na tabela para apaga-la!");
    	}
    }

    /**
     * atualiza a tabela de leitura
     */
    private void updateview() {
    	String colunas[] = {NameConfig.Authors_id, NameConfig.Authors_name, NameConfig.Authors_fname};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
        AuthorsController pc = new AuthorsController();
        List<AuthorsModel> lista = pc.listAll();
        for(AuthorsModel p: lista){
            modelo.addRow(new String[]{String.valueOf(p.getAuthor_Id()), p.getName(), p.getFname()});
        }

        tableAuthors.setModel(modelo);
    }

    /**
     * executado sempre que a a��o {@link evt} � realizada
     * @param evt - Bot�o "editar" presionado
     */
    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {
    	try {
    		int idx = Integer.parseInt(tableAuthors.getModel().getValueAt(tableAuthors.getSelectedRow(), 0).toString());
    		String name = tableAuthors.getModel().getValueAt(tableAuthors.getSelectedRow(), 1).toString();
    		name = name.replaceAll(" +", " ");
    		String fname = name.substring(0, name.indexOf(' '));
    		AuthorsController pc = new AuthorsController();
    		pc.update(idx, name, fname);
    		JOptionPane.showMessageDialog(null, fname + " modificado com sucesso!");
    		updateview();
    	} catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, "Houve um problema na sua conex�o com o banco de dados!");
    	} catch (ArrayIndexOutOfBoundsException e) {
    		JOptionPane.showMessageDialog(null, "Selecione uma linha na tabela para edita-la!");
    	}
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AuthorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AuthorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AuthorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AuthorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AuthorView().setVisible(true);
            }
        });
    }

    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblName;
    private javax.swing.JTable tableAuthors;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtName;
}
