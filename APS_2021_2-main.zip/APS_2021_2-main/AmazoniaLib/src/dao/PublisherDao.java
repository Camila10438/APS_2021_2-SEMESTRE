package dao;

import assets.VarText;
import model.PublishersModel;
import java.sql.SQLException;
import java.util.List;

public class PublisherDao extends GenericDao {

	/**
	 * Executa um INSERT em sql
	 * @param table tabela onde o dado ser� inserido
	 * @param data dados a serem inseridos
	 * @throws SQLException - caso haja problema na conex�o com o banco de dados
	 */
    public void save(String table, String[] data) throws SQLException {
        String sql = "INSERT INTO publishers(publisher_id, name, url) VALUES " + VarText.listText(data);
        save(sql, Integer.parseInt(data[0]) , data[1], data[2]);
    }

    /**
     * Retorna uma lista completa de editoras
     * @return lista de editoras
     * @throws SQLException -  - caso haja problema na conex�o com o banco de dados
     */
    public List<PublishersModel> listarTodos() throws SQLException {
        return listAllPublishers();
    }
    
    /**
     * Apaga um dado do registro
     * @param parametros dados a serem apagados
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void delete(Object... parametros) throws SQLException {
    	exeStm("DELETE FROM publishers WHERE publisher_id = ?", parametros);
    }

    /**
     * Atualiza uma editora do registro
     * @param publisher_id id da editora
     * @param name novo nome da editora
     * @param url novo url da editora
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void update(Object publisher_id, Object name, Object url) throws SQLException {
    	exeStm("UPDATE publishers SET name = ?, url = ? WHERE publisher_id = ?", name, url, publisher_id);
    }
    
}