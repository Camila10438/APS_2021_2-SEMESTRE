package dao;

import model.BooksModel;
import java.sql.SQLException;
import java.util.List;

public class BookDao extends GenericDao {

	/**
	 * Executa um INSERT em sql
	 * @param table tabela onde o dado ser� inserido
	 * @param data dados a serem inseridos
	 * @throws SQLException - caso haja problema na conex�o com o banco de dados
	 */
    public void save(String table, String[] data) throws SQLException {
        String sql = "INSERT INTO books(title, isbn, publisher_id, price) VALUES (?, ?, ?, ?)";
        save(sql, data[0], Integer.parseInt(data[1]), Integer.parseInt(data[2]), Double.parseDouble(data[3]));
    }

    /**
     * Retorna uma lista completa de livros
     * @return lista de livros
     * @throws SQLException -  - caso haja problema na conex�o com o banco de dados
     */
    public List<BooksModel> listarTodos() throws SQLException {
        return listAllBooks();
    }
    
    /**
     * Apaga um dado do registro de livros
     * @param parametros dados a serem apagados
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void delete(Object... parametros) throws SQLException {
    	exeStm("DELETE FROM books WHERE title = ?", parametros);
    }

    /**
     * atualiza um livro do registro
     * @param title t�tulo do livro
     * @param isbn c�digo de identifica��o do livro
     * @param id id da editora
     * @param price pre�o do livro
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void update(Object title, Object isbn, Object id, Object price) throws SQLException {
    	exeStm("UPDATE books SET title = ?, publisher_id = ?, price = ? WHERE isbn = ?", title, id, price, isbn);
    }    
}