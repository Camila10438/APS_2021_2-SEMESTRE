package dao;

import model.AuthorsModel;
import model.BooksAuthorsModel;
import model.BooksModel;
import model.PublishersModel;
import sql.ConnectionDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public abstract class GenericDao {
	
	/**
	 * Objeto de Conex�o
	 */
    private Connection connection;

    /**
     * Abre a Conex�o
     */
    protected GenericDao() {
        this.connection = ConnectionDataBase.getConnection();
    }

    /**
     * Retorna a conex�o
     * @return um objeto conex�o pronto
     */
    protected Connection getConnection() {
        return connection;
    }

    /**
     * Executa um comando insert em sql
     * @param insertSql c�digo base e tabela onde ser� inserido
     * @param parametros os dados a serem inseridos
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    protected void save(String insertSql, Object... parametros) throws SQLException {
        PreparedStatement pstmt = getConnection().prepareStatement(insertSql);

        for (int i = 0; i < parametros.length; i++) {
            pstmt.setObject(i+1, parametros[i]);
        }

        pstmt.execute();
        pstmt.close();
        connection.close();
    }

    /**
     * retorna um lista com todas as editoras requeridas
     * @return lista de editoras
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    protected List<PublishersModel> listAllPublishers() throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs;

        rs = stmt.executeQuery("SELECT publisher_id, name, url FROM publishers");
        List<PublishersModel> lista = new ArrayList<>();
        while (rs.next()) {
            PublishersModel pm = new PublishersModel();
            Integer idPublisher = rs.getInt("publisher_id");
            String name =rs.getString("name");
            String url =rs.getString("url");
            pm.setPublisher_Id(idPublisher);
            pm.setName(name);
            pm.setUrl(url);
            lista.add(pm);
        }
        return lista;
    }

    /**
     * retorna um lista com todas os autores requeridos
     * @return lista de autores
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    protected List<AuthorsModel> listAllAuthors() throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs;

        rs = stmt.executeQuery("SELECT author_id, name, fName FROM authors");
        List<AuthorsModel> lista = new ArrayList<>();
        while (rs.next()) {
            AuthorsModel pm = new AuthorsModel();
            Integer idPublisher = rs.getInt("author_id");
            String name =rs.getString("name");
            String url =rs.getString("fName");
            pm.setAuthor_Id(idPublisher);
            pm.setName(name);
            pm.setFname(url);
            lista.add(pm);
        }
        return lista;
    }

    /**
     * retorna um lista com todas os livros requeridos
     * @return lista de livros
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    protected List<BooksModel> listAllBooks() throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs;

        rs = stmt.executeQuery("SELECT title, isbn, publisher_id, price FROM books");
        List<BooksModel> lista = new ArrayList<>();
        while (rs.next()) {
            BooksModel pm = new BooksModel();
            String title        = rs.getString("title");
            String isbn        = rs.getString("isbn");
            Integer publisher_id = rs.getInt("publisher_id");
            double price       = rs.getDouble("price");
            pm.setTitle(title);
            pm.setIsbn(isbn);
            pm.setPublisher_Id(publisher_id);
            pm.setPrice(price);
            lista.add(pm);
        }
        return lista;
    }

    /**
     * retorna um lista com a rela��o entre livros e autores
     * @return lista relativa de livros e editoras
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    protected List<BooksAuthorsModel> listAllBooksAuthors() throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs;

        rs = stmt.executeQuery("SELECT isbn, author_id, seq_no FROM booksauthors");
        List<BooksAuthorsModel> lista = new ArrayList<>();
        while (rs.next()) {
            BooksAuthorsModel pm = new BooksAuthorsModel();
            String isbn       = rs.getString("isbn");
            Integer authors_id = rs.getInt("author_id");
            Integer seq_no    = rs.getInt("seq_no");
            pm.setIsbn(isbn);
            pm.setAuthor_id(authors_id);
            pm.setSeq_no(seq_no);
            lista.add(pm);
        }
        return lista;
    }

    /**
     * executa um comando simples em sql
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    protected void exeStm(String stmt, Object... parametros) throws SQLException {
    	PreparedStatement pstmt = getConnection().prepareStatement(stmt);
    	
        for (int i = 0; i < parametros.length; i++) {
            pstmt.setObject(i+1, parametros[i]);
        }

        pstmt.execute();
        pstmt.close();
    }
}