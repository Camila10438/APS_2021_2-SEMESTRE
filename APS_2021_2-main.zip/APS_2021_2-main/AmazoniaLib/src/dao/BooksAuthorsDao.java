package dao;

import model.BooksAuthorsModel;
import java.sql.SQLException;
import java.util.List;

import assets.VarText;

public class BooksAuthorsDao extends GenericDao {

	/**
	 * Executa um INSERT em sql
	 * @param table tabela onde o dado ser� inserido
	 * @param data dados a serem inseridos
	 * @throws SQLException - caso haja problema na conex�o com o banco de dados
	 */
	public void save(String table, String[] data) throws SQLException {
		String sql = "INSERT INTO booksauthors(isbn, author_id, seq_no) VALUES " + VarText.listText(data);
        save(sql, Integer.parseInt(data[0]) , Integer.parseInt(data[1]), Integer.parseInt(data[2]));
    }

	/**
     * Retorna uma lista completa de booksauthors
     * @return lista de booksauthors
     * @throws SQLException -  - caso haja problema na conex�o com o banco de dados
     */
    public List<BooksAuthorsModel> listarTodos() throws SQLException {
        return listAllBooksAuthors();
    }
    
    /**
     * Apaga um dado do registro de booksauthors
     * @param parametros dados a serem apagados
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
	public void delete(Object... parametros) throws SQLException {
		exeStm("DELETE FROM booksauthors WHERE seq_no = ?", parametros);
	}

	/**
     * atualiza uma rela��o booksauthor do registro
     * @param isbn c�digo de identifica��o do livro
     * @param id id do autor
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void update(Object id, Object seq) throws SQLException {
    	exeStm("UPDATE booksauthors SET author_id = ? WHERE seq_no = ?", id, seq);
    }
    
}