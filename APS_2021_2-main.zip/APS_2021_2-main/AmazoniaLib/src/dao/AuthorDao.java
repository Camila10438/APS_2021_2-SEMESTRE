package dao;

import assets.VarText;
import model.AuthorsModel;
import java.sql.SQLException;
import java.util.List;

public class AuthorDao extends GenericDao {

	/**
	 * Executa um INSERT em sql
	 * @param table tabela onde o dado ser� inserido
	 * @param data dados a serem inseridos
	 * @throws SQLException - caso haja problema na conex�o com o banco de dados
	 */
    public void save(String table, String[] data) throws SQLException {
        String sql = "INSERT INTO authors(author_id, name, fname) VALUES " + VarText.listText(data);
        save(sql, Integer.parseInt(data[0]) , data[1], data[2]);
    }

    /**
     * Retorna uma lista completa de Autores
     * @return lista de autores
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public List<AuthorsModel> listarTodos() throws SQLException {
        return listAllAuthors();
    }
    
    /**
     * Apaga um dado do registro
     * @param parametros dados a serem apagados
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void delete(Object... parametros) throws SQLException {
    	exeStm("DELETE FROM authors WHERE author_id = ?", parametros);
    }

    /**
     * Atualiza um autor do registro
     * @param author_id id do autor
     * @param name nome do autor
     * @param fname primeiro nome do autor
     * @throws SQLException - caso haja problema na conex�o com o banco de dados
     */
    public void update(Object author_id, Object name, Object fname) throws SQLException {
    	exeStm("UPDATE authors SET name = ?, fname = ? WHERE author_id = ?", name, fname, author_id);
    }
    
}